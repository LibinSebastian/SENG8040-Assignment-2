﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2___SENG_8040
{
    public static class TriangleSolverClass
    {
        public static string AnalyzeTriangleMethod(int SideA, int SideB, int SideC)
        {
            string ResultOfTriangleStored = string.Empty;
            if ((SideA + SideB > SideC) && (SideA + SideC > SideB) && (SideB + SideC > SideA))
            {
                do
                {
                    if (SideA == SideB && SideB == SideC)
                    {
                        ResultOfTriangleStored = "As Per The Entries Equilateral Triangle Is Formed";
                    }
                    else if ((SideA == SideB) || (SideB == SideC) || (SideA == SideC))
                    {
                        ResultOfTriangleStored = "As Per The Entries Isoceles Triangle Is Formed";
                    }
                    else
                    {
                        ResultOfTriangleStored = "As Per The Entries Scalene Triangle Is Formed";
                    }
                }
                while (!(SideA + SideB > SideC) && (SideA + SideC > SideB) && (SideB + SideC > SideA));
            }
            else
            {
                ResultOfTriangleStored = "As Per The Entered Values Triangle Cannot Be Formed!";
            }

            Console.WriteLine(ResultOfTriangleStored);

            return ResultOfTriangleStored;
        }

   
 }

}

