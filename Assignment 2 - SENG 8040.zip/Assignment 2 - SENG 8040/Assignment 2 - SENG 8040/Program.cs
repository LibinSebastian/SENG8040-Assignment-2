﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2___SENG_8040;

namespace Assignment02
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Assignment 2: SENG 8040");
            string resOf = string.Empty;
            int SideA, SideB, SideC;
            bool flagSetTo = false;
            while (flagSetTo == false)
            {
                do
                {
                    Console.Write("Select From Either Options To Continue............\n ");
                    Console.WriteLine("1. Enter The Triangle Dimension: \n");

                    Console.WriteLine("2. Exit \n");
                    
                    
                    resOf = Console.ReadLine();

                    if (resOf != "1" && resOf != "2")
                    {

                        Console.WriteLine("The Value Entered Is Not A Valid One. Please Enter A Value That's Valid!");

                    }

                    else if (resOf == "2")
                    {

                        Environment.Exit(0);

                    }

                    else
                    {
                       
                        SideA = ValidationOfUsersInput("Side A Of Triangle");

                        SideB = ValidationOfUsersInput("Side B Of Triangle");

                        SideC = ValidationOfUsersInput("Side C Of Triangle");

                        flagSetTo = true;

                        resOf = TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
                    }

                    Console.WriteLine();
                    Console.ReadKey();
                } while (!(resOf == "1" || resOf == "2"));
            }
        }
        public static int ValidationOfUsersInput(string SideOfTri)
        {
            int s;
            bool isValueValidated = false;
            string sideSelofTri = string.Empty;
            while (isValueValidated == false)
            {
                Console.Write("Enter Side Of Triangle : ", SideOfTri);

                sideSelofTri = Console.ReadLine();
                bool result = int.TryParse(sideSelofTri, out s);

                if (s > 0)
                {
                    isValueValidated = true;
                }
                else if (s <= 0)

                {
                    Console.WriteLine("Please Provide A Valid Input!");

                    Console.WriteLine("Triangle Can't Recieve Value Less Than / Equal To '0'.");
                }
            }

            Console.WriteLine();


            return (int.Parse(sideSelofTri));
        }


    }
}
