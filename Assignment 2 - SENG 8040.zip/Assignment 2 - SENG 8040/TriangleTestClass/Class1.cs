﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2___SENG_8040;
using NUnit.Framework;

namespace TriangleTestClass
{
 [TestFixture]
 class TriangleTestClass
    {
        //Test 1: For Triangle That Can't Be Created
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas1_InputSideBas2_InoutSideCas5_Expected_NoTriangleIsFormed()
        {
            //Arrange
            int SideA = 1;
            int SideB = 2;
            int SideC = 5;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            string expectedString = "As Per The Entered Values Triangle Cannot Be Formed!";
            
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA,SideB,SideC);
           
            //Assert
            Assert.AreEqual(expectedString, actualString);
        }
        //End Of Test

        //Test 2: For Triangle That Can't Be Created
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas1_InputSideBas2_InputSideCas3_Expected_NoTriangleIsFormed()
        {
            //Arrange
            int SideA = 1;
            int SideB = 2;
            int SideC = 3;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            string expectedString= "As Per The Entered Values Triangle Cannot Be Formed!";
            
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA,SideB,SideC);
        
            //Assert
            Assert.AreEqual(expectedString, actualString);
        }
        //End Of Test

        //Test 3: Checking Whether The Triangle Is Isoceles
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas2_InputSideBas2_InputSideas3_Expected_IsocelesTriangleFormed()
        {
            //Arrange 
            int SideA = 2;
            int SideB = 2;
            int SideC = 3;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            string expectedString = "As Per The Entries Isoceles Triangle Is Formed";
            
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
        
            //Assert
            Assert.AreEqual(expectedString, actualString);
        }
        //End Of Test

        //Test 4: Checking Whether The Triangle Is Isoceles
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas5_InputSideBas5_InputSideCas6_Expected_IsocelesTriangleFormed()
        {
            //Arrange
            int SideA = 5;
            int SideB = 5;
            int SideC = 6;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            string expectedString = "As Per The Entries Isoceles Triangle Is Formed";
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            //Assert
            Assert.AreEqual(expectedString,actualString);
        }
        //End Of Test

        //Test 5: Checking Whether The Traingle Is Equilateral
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas5_InputSideBas5_InputSideCas5_Expected_EquilateralTriangleFormed()
        {
            //Arrange
            int SideA = 5;
            int SideB = 5;
            int SideC = 5;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA,SideB,SideC);
            string expectedString = "As Per The Entries Equilateral Triangle Is Formed";
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            //Assert
            Assert.AreEqual(expectedString,actualString);
        }
        //End Of Test

        //Test 6: Checking Whether The Traingle Is Equilateral
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas12_InputSideBas12_InputSideCas12_Expected_EquilateralTriangleFormed()
        {
            //Arrange
            int SideA = 12;
            int SideB = 12;
            int SideC = 12;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            string expectedString = "As Per The Entries Equilateral Triangle Is Formed";
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            //Assert
            Assert.AreEqual(expectedString, actualString);
        }
        //End Of Test

        //Test 7: Checking Whether The Traingle Is Scalene
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas12_SideBas15_SideCas17_Expected_ScaleneTriangleFormed()
        {
            //Arrange
            int SideA = 12;
            int SideB = 15;
            int SideC = 17;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA,SideB,SideC);
            string expectedString = "As Per The Entries Scalene Triangle Is Formed";
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            //Assert
            Assert.AreEqual(expectedString, actualString);
        }
        //End Of Test

        //Test 8: Checking Whether The Triangle Is Scalene
        [Test]
        public void AnalyzeTriangleMethod_InputSideAas22_SideBas35_SideCas17_Expected_ScaleneTriangleFormed()
        {
            //Arrange
            int SideA = 22;
            int SideB = 35;
            int SideC = 17;
            TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            string expectedString = "As Per The Entries Scalene Triangle Is Formed";
            //Act
            string actualString = TriangleSolverClass.AnalyzeTriangleMethod(SideA, SideB, SideC);
            //Assert
            Assert.AreEqual(expectedString, actualString);
        }
    }
}
 
